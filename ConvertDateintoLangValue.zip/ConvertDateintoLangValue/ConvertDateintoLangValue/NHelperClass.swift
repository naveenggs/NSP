//
//  NHelperClass.swift
//  ConvertDateintoLangValue
//
//  Created by Naveen Gundu on 25/09/17.
//  Copyright © 2017 NSP. All rights reserved.
//

import UIKit
import CoreGraphics
import Foundation

class NHelperClass {
    
    let offsetTime = TimeInterval(NSTimeZone.local.secondsFromGMT())

    func DateInMiliseconds(dateStr:String, dateFormat:String) -> Int {
        
        let dateFormatter = DateFormatter()
        
        dateFormatter.dateFormat = dateFormat
        
        let Ndate = dateFormatter.date(from: dateStr)
        
        let dateLocal = Ndate?.addingTimeInterval(+offsetTime)
        
        let since1970 = dateLocal?.timeIntervalSince1970
        
        return Int(since1970! * 1000)
    }
    

}
