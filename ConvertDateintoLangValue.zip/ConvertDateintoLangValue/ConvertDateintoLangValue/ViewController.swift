//
//  ViewController.swift
//  ConvertDateintoLangValue
//
//  Created by Naveen Gundu on 25/09/17.
//  Copyright © 2017 NSP. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var lblDateN: UILabel!
    
    @IBOutlet var lblLangvalue: UILabel!
    
    var dateStr = String()
    var langValue = Int()
    var dateFormatter = String()
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    self.SettingAllViewwithData()
        
    }
    
    func SettingAllViewwithData() {
        
        
        self.dateStr = "01-01-2018"
        
        self.dateFormatter = "dd-MM-yyyy"
        
        self.lblDateN.text = self.dateStr
        
        //Using NHelperClass to Convert Date into Lang Value
        
        self.langValue = NHelperClass().DateInMiliseconds(dateStr: self.dateStr, dateFormat: self.dateFormatter)
        
        
        self.lblLangvalue.text = String(self.langValue)
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

