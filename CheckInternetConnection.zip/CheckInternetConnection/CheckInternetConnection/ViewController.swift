//
//  ViewController.swift
//  CheckInternetConnection
//
//  Created by Naveen Gundu on 25/09/17.
//  Copyright © 2017 NSP. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet var lblInternetStatus: UILabel!
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        
        //Using NHelperClass Method to find Internet is Active or Not???
        
        NHelperClass().checkInternetAvailable(dynamicVC: self, Avaialable: { 
            
            // Active Internet Connection
            
            self.lblInternetStatus.text = "Active"
            self.lblInternetStatus.textColor = UIColor.blue

            
            
        }) { 
            
            //Noo Active Internet
            
            self.lblInternetStatus.text = "In Active"
            self.lblInternetStatus.textColor = UIColor.red
        

        }
        
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

