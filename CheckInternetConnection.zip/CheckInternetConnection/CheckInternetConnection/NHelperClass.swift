//
//  NHelperClass.swift
//  CheckInternetConnection
//
//  Created by Naveen Gundu on 25/09/17.
//  Copyright © 2017 NSP. All rights reserved.
//

import UIKit
import CoreGraphics
import Foundation
import SystemConfiguration

open class NHelperClass {
   
    func isInternetAvailable() -> Bool
    {
        var zeroAddress = sockaddr_in()
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        
        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }
        
        var flags = SCNetworkReachabilityFlags()
        if !SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) {
            return false
        }
        let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
        let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
        return (isReachable && !needsConnection)
    }
    
    
    func checkInternetAvailable(dynamicVC: UIViewController, Avaialable: @escaping () -> Void, NotAvailable:@escaping () -> Void) {
        
        
        if NHelperClass().isInternetAvailable() {
            
            Avaialable()
            
        }
        else
        {
            NotAvailable()
            
            DispatchQueue.main.async {
                
                let internetAlert = UIAlertController(title: "No Internet Connection", message: "Please make Sure your Internet is Active !!!", preferredStyle: UIAlertControllerStyle.alert)
            
        
                let dismiss: UIAlertAction = UIAlertAction(title: "Retry", style: .cancel) { action -> Void in
               
                    self.checkInternetAvailable(dynamicVC: dynamicVC, Avaialable: Avaialable, NotAvailable: NotAvailable)
                    
                }
                
                internetAlert.addAction(dismiss)
              
                dynamicVC.present(internetAlert, animated: true, completion: nil)
                
            }
            
        }

    }

}
